from django.contrib import admin
from .models import publicar

admin.site.register(publicar)
